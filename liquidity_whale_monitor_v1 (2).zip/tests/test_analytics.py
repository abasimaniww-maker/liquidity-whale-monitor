from datetime import datetime, timezone
from app.models import Trade, OrderBook
from app.analytics import trade_value, net_flow, vwap, large_trades, depth_imbalance

def sample():
    now = datetime.now(timezone.utc)
    return [
        Trade(trade_id="1", symbol="ABC", price=10, quantity=5, side="BUY", timestamp=now),
        Trade(trade_id="2", symbol="ABC", price=12, quantity=2, side="SELL", timestamp=now),
    ]

def test_trade_value():
    assert trade_value(10, 5) == 50

def test_net_flow():
    result = net_flow(sample())
    assert result["net_flow"] == 26

def test_vwap():
    assert vwap(sample()) == (10*5 + 12*2)/7

def test_large_trade_filter():
    assert len(large_trades(sample(), 50)) == 1

def test_depth_imbalance():
    book = OrderBook(symbol="ABC", bids=[(10, 5)], asks=[(11, 3)])
    assert depth_imbalance(book) == 0.25
